"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
exports.auth = void 0;
var app_1 = require("firebase-admin/app");
var auth_1 = require("firebase-admin/auth");
var credential_1 = require("firebase-admin/lib/credential");
var firebaseAccountKey_json_1 = __importDefault(require("../json/firebaseAccountKey.json"));
var app = (0, app_1.initializeApp)({
    credential: credential_1.credential.cert(firebaseAccountKey_json_1["default"])
});
exports.auth = (0, auth_1.getAuth)(app);
