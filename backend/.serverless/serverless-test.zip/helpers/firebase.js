"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
exports.auth = void 0;
var firebase_admin_1 = __importDefault(require("firebase-admin"));
var firebaseAccountKey_json_1 = __importDefault(require("../json/firebaseAccountKey.json"));
var app = firebase_admin_1["default"].initializeApp({
    credential: firebase_admin_1["default"].credential.cert(firebaseAccountKey_json_1["default"])
});
exports.auth = firebase_admin_1["default"].auth(app);
