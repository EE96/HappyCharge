"use strict";
exports.__esModule = true;
exports.notFoundResponse = exports.serverErrorResponse = exports.badRequestResponse = exports.successResponse = void 0;
var successResponse = function (bodyObject) {
    if (bodyObject === void 0) { bodyObject = ""; }
    return ({
        statusCode: 200,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': true
        },
        body: JSON.stringify(bodyObject, null, 2)
    });
};
exports.successResponse = successResponse;
var badRequestResponse = function (message) {
    if (message === void 0) { message = "Bad Request"; }
    return ({
        statusCode: 400,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': true
        },
        body: JSON.stringify({
            message: message
        }, null, 2)
    });
};
exports.badRequestResponse = badRequestResponse;
var serverErrorResponse = function (message) {
    if (message === void 0) { message = "Internal Server Error"; }
    return ({
        statusCode: 500,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': true
        },
        body: JSON.stringify({
            message: message
        }, null, 2)
    });
};
exports.serverErrorResponse = serverErrorResponse;
var notFoundResponse = function (message) {
    if (message === void 0) { message = "Not Found"; }
    return ({
        statusCode: 404,
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': true
        },
        body: JSON.stringify({
            message: message
        }, null, 2)
    });
};
exports.notFoundResponse = notFoundResponse;
